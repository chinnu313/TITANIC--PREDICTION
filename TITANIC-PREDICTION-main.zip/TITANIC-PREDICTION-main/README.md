# TITANIC-PREDICTION
The Titanic survival prediction problem is a well-known classification task in machine learning, where the goal is to predict whether a passenger survived or perished in the Titanic disaster based on certain features. This dataset is often used as an introductory project for data science and machine learning practitioners.
